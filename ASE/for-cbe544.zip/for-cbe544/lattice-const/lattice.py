#!/usr/bin/env python
import numpy as np

from ase import io
from espresso import espresso


atoms =  io.read('sto-bulk.traj') #Read trajectory

convergence = {'energy':1e-5,     #SCF convergence settings   
                'mixing':0.05,
                'nmix':10,
                'maxsteps':500,
                'diag':'david'
                }

output = {'avoidio':False,       #QE output directives
        'removewf':True,
        'wf_collect':False}

calc = espresso(pw=600 , # Plane wave cutoff
    dw=6000, # Density wave cutoff
    nbands=-50,
    smearing='gauss',
    kpts=(5,5,5), # k-point (Brillouin) sampling
    xc='PBE', #Exchange-correlation functional
    parflags='-npool 2',
    convergence=convergence,
    outdir = 'calcdir', #QE generated files will be put here
    output = output,) 


atoms.set_calculator(calc)#Assign calculator to atoms

cell=atoms.get_cell() #Get cell dimensions

traj=io.Trajectory('sto.traj','w')# Write output to .traj

for x in np.linspace(0.90, 1.10, 10): #Varying the cell size and computing single point energies
    atoms.set_cell(cell*x, scale_atoms=True)
    atoms.get_potential_energy()
    traj.write(atoms)

