#!/usr/bin/env python


from ase.utils.geometry import sort
from ase import optimize
#from ase.io.vasp import read_vasp
from ase.io import write,read
from espresso import espresso
#from ase.io.trajectory import PickleTrajectory
#from ase.calculators.emt import EMT
import numpy as np
from ase.visualize import  view

posin=read("ini.traj")
p=posin.copy()

convergence = {'energy':1e-5,
                'mixing':0.05,
                'nmix':10,
                'maxsteps':500,
                'diag':'david'
                }

output = {'avoidio':False,
        'removewf':True,
        'wf_collect':False}

calc = espresso(pw=500 , # Plane wave cutoff
    dw=5000, # Density wave cutoff
    #spinpol=True,
    nbands=-50,
    smearing='gauss',
    #sigma=0.2,
    kpts=(5,5,1), # (rather sparse) k-point (Brillouin) sampling
    xc='PBE', #Exchange-correlation functional
    dipole={'status':True}, # Includes dipole correction (necessary for asymmetric slabs)
    #psppath='/global/homes/b/brightzh/eds_scratch/perovsike/quanesp/SFO/cell_opt/',
    parflags='-npool 2',
    convergence=convergence,
    #U={'Fe':5.3},
    #U_projection_type='atomic',
    outdir = 'esp.log',
    output = output,) # Espresso-generated files will be put here

#view(p)
#mag0=40*[0]
#mag_afm=[4, -4, 4, -4, 4, -4, -4, 4, -4, 4, -4 , 4]+48*[0]
#mag_aafm=[3,-3,3,-3,3,-3,3,-3]+32*[0]
#mag_cafm=[3,3,-3,-3,-3,-3,3,3]+32*[0]
#mag_gafm=[3,-3,-3,3,3,-3,-3,3]+32*[0]

#p.set_initial_magnetic_moments(mag_afm)
#calc.calculation_required = lambda x, y: True
mag0=len(p)*[0]
p.set_initial_magnetic_moments(mag0)
p.set_calculator(calc)
#calc.load_wf('wf.tgz')
qn = optimize.QuasiNewton(p,trajectory='relax.traj',logfile='relax.log')
qn.run(fmax=0.03)
#pe=p.get_potential_energy()
calc.save_wf('wf.tgz')
#write('fin.traj',p)

#print "[Energy] = "+str(pe)

#del p



